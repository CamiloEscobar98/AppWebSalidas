
<?php $__env->startSection('title', 'Perfil-Director'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session()->has('update_complete')): ?>
            <div class="alert alert-success">
                <strong>¡Éxito!</strong> Se ha actualizado correctamente.
            </div>
        <?php endif; ?>
        <?php if(session()->has('update-photo')): ?>
            <div class="alert alert-success">
                <strong>¡Éxito!</strong> Se ha actualizado correctamente la foto de perfil.
            </div>
        <?php endif; ?>
        <?php if(session()->has('update-password')): ?>
            <div class="alert alert-success">
                <strong>¡Éxito!</strong> Se ha actualizado correctamente la contraseña.
            </div>
        <?php endif; ?>
        <?php $__errorArgs = ['image_profile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <strong>¡Error!</strong> <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <strong>¡Error!</strong> <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="row">
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header bg-appsalidas py-4">
                        <h4 class="font-weight-bold my-1">Perfil Director</h4>
                    </div>
                    <div class="card-body">
                        <button class="btn btn-appsalidas2 float-left" data-toggle="modal"
                            data-target="#changePassword">Cambiar contraseña</button>
                        <button class="btn btn-appsalidas2 float-right" data-toggle="modal"
                            data-target="#changePhoto">Cambiar
                            foto de perfil</button>
                        <img src="<?php echo e(asset($director->image->url . '/' . $director->image->image)); ?>"
                            class="img-fluid mx-auto d-block" width="200vh">
                        <hr>
                        <form action="<?php echo e(route('user.update')); ?>" method="post" class="my-4">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-bold">Nombres:</label>
                                        <input type="text" name="name" class="form-control text-capitalize"
                                            value="<?php echo e($director->name); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Apellidos:</label>
                                        <input type="text" name="lastname" class="form-control text-capitalize"
                                            value="<?php echo e($director->lastname); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Código:</label>
                                        <input type="text" name="code" class="form-control" value="<?php echo e($director->code); ?>"
                                            aria-describedby="helpId" maxlength="7">
                                        <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Correo Personal:</label>
                                        <input type="text" name="email" class="form-control" value="<?php echo e($director->email); ?>"
                                            aria-describedby="helpId">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Correo universitario:</label>
                                        <input type="text" name="emailu" class="form-control"
                                            value="<?php echo e($director->emailu); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['emailu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Programa al que pertenece:</label>
                                        <select class="custom-select text-capitalize" name="program_id">
                                            <option value="-1">Seleccione un programa</option>
                                            <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($director->program->code == $program->code): ?>
                                                    <option value="<?php echo e($program->id); ?>" class="text-capitalize" selected>
                                                        <?php echo e($program->name); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($program->id); ?>" class="text-capitalize">
                                                        <?php echo e($program->name); ?>

                                                    </option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['program_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="font-weight-bold">Dirección de Residencia:</label>
                                        <input type="text" name="address" class="form-control text-capitalize"
                                            value="<?php echo e($director->address); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Teléfono Celular:</label>
                                        <input type="text" name="phone" class="form-control text-capitalize"
                                            value="<?php echo e($director->phone); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Documento:</label>
                                        <input type="text" name="document" class="form-control text-capitalize"
                                            value="<?php echo e($director->document->document); ?>" aria-describedby="helpId">
                                        <?php $__errorArgs = ['document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Tipo de Documento:</label>
                                        <select class="custom-select text-capitalize" name="document_type_id">
                                            <option value="-1">Seleccione un Tipo de Documento</option>
                                            <?php $__currentLoopData = $document_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doct_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($director->document->dtype->type == $doct_type->type): ?>
                                                    <option value="<?php echo e($doct_type->id); ?>" class="text-capitalize" selected>
                                                        <?php echo e($doct_type->name); ?>

                                                    </option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($doct_type->id); ?>" class="text-capitalize">
                                                        <?php echo e($doct_type->name); ?>

                                                    </option>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['document_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label class="font-weight-bold">Fecha de Nacimiento:</label>
                                        <input type="date" name="birthday" class="form-control text-capitalize"
                                            value="<?php echo e($director->birthday); ?>" aria-describedby="helpId" min="1940-01-01"
                                            max="2004-12-31">
                                        <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small id="helpId" class="text-white bg-appsalidas"><?php echo e($message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-block btn-appsalidas">Actualizar</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-appsalidas py-4"></div>
                </div>
            </div>
            <div class="col-md-7">
                <div class="card">
                    <div class="card-header bg-appsalidas py-4">
                        <h4 class="font-weight-bold my-1">Mis Actividades</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead-inverse">
                                    <tr class="bg-appsalidas">
                                        <th>No.</th>
                                        <th>Actividad</th>
                                        <th>Descripción</th>
                                        <th>Inicio</th>
                                        <th>Fin</th>
                                        <th>...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td scope="row"></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer bg-appsalidas py-4">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal" id="changePhoto">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-appsalidas py-5">
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('user.update-photo')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <input type="hidden" name="user_email" value="<?php echo e($director->emailu); ?>">
                        <div class="form-group">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFile" name="image_profile">
                                <label class="custom-file-label" for="customFile">Seleccione una imágen de perfil</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-appsalidas2">Actualizar foto de perfil</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal" id="changePassword">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-appsalidas py-5">
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('user.update-password')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="form-group">
                            <label class="font-weight-bold">Nueva Contraseña:</label>
                            <input class="form-control" type="password" name="password">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-block btn-appsalidas2">Actualizar Contraseña</button>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(".custom-file-input").on("change", function() {
            var fileName = $(this).val().split("\\").pop();
            $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\AppWebSalidas\resources\views/auth/profiles/director.blade.php ENDPATH**/ ?>