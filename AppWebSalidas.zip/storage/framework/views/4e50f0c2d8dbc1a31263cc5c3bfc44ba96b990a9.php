<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-dark bg-appsalidas shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand py-1" href="<?php echo e(url('/')); ?>">
                    <h3> <?php echo e(config('app.name', 'Laravel')); ?></h3>
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('user.home')); ?>" class="nav-link">Perfil</a>
                            </li>
                            <?php if(session('role') == 'administrador'): ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                        Listas de Usuarios
                                    </a>
                                    <div class="dropdown-menu">
                                        <a class="dropdown-item" href="<?php echo e(route('students')); ?>">Estudiantes</a>
                                        <a class="dropdown-item" href="<?php echo e(route('teachers')); ?>">Docentes</a>
                                        <a class="dropdown-item" href="<?php echo e(route('directors')); ?>">Directores</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('faculties')); ?>" class="nav-link">Facultades</a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('programs')); ?>" class="nav-link">Programas</a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>">Iniciar Sesión</a>
                            </li>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-capitalize" href="#"
                                    role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->lastname); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                                                                                                                                 document.getElementById('logout-form').submit();">
                                        Cerrar Sesión
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4" id="content-body">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <footer>
            <div class="container-fluid bg-appsalidas py-3">
                Créditos para
            </div>
        </footer>
        <?php echo $__env->yieldContent('scripts'); ?>
    </div>
</body>

</html>
<?php /**PATH C:\wamp64\www\proyectos\Software\AppWebSalidas\resources\views/layouts/app.blade.php ENDPATH**/ ?>