
<?php $__env->startSection('title', 'Perfil-Programa'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div>
            <?php if(session()->has('update_complete')): ?>
                <div class="alert alert-success">
                    <strong>¡Éxito!</strong> <?php echo e(session('update_complete')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('update_failed')): ?>
                <div class="alert alert-danger">
                    <strong>¡Error!</strong> <?php echo e(session('update_failed')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header bg-appsalidas py-4">
                        <h4 class="font-weight-bold my-1">Perfil Programa</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('program.update')); ?>" method="post" class="my-4">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($program->id); ?>">
                            <?php echo method_field('put'); ?>
                            <div class="form-group">
                                <label class="font-weight-bold">Nombre del programa:</label>
                                <input type="text" name="name" class="form-control"
                                    placeholder="Introduzca el nombre del programa" aria-describedby="helpId"
                                    value="<?php echo e($program->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-appsalidas font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Código:</label>
                                <input type="text" name="code" class="form-control"
                                    placeholder="Introduzca el código del programa" aria-describedby="helpId"
                                    value="<?php echo e($program->code); ?>" maxlength="7"
                                    onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-appsalidas font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Selecciona una facultad:</label>
                                <select name="faculty_id" class="custom-select text-capitalize" aria-describedby="helpId">
                                    <option value="-1">Selecciona una facultad</option>
                                    <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($faculty->id == $program->faculty->id): ?>
                                            <option value="<?php echo e($faculty->id); ?>" selected><?php echo e($faculty->name); ?></option>
                                        <?php endif; ?>
                                        <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['faculty_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-appsalidas font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-block btn-appsalidas">Actualizar</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-appsalidas py-4"></div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header bg-appsalidas py-4">
                                <h4 class="my-0 font-weight-bold">Lista de Docentes</h4>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Acá puede visualizar todo los docentes que se encuentran registrados.
                                </h5>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead class="thead-inverse bg-appsalidas">
                                            <tr class="text-center">
                                                <th class="font-weight-bold w-auto">Código</th>
                                                <th class="font-weight-bold w-25">Docente</th>
                                                <th class="font-weight-bold w-auto">Correo Institucional</th>
                                                <th class="font-weight-bold w-auto">...</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr class="text-center" id="fila1<?php echo e($loop->iteration); ?>">
                                                    <td><?php echo e($teacher->code); ?></td>
                                                    <td class="text-capitalize"><?php echo e($teacher->name); ?> <?php echo e($teacher->lastname); ?>

                                                    </td>
                                                    <td><?php echo e($teacher->emailu); ?></td>
                                                    <td>
                                                        <div class="btn-group w-100">
                                                            <a href="<?php echo e(route('user.show-teacher', $teacher)); ?>"
                                                                class="btn btn-info  mr-2">Visualizar</a>
                                                            <button class="btn btn-danger delete-teacher"
                                                                data-tr="<?php echo e($loop->iteration); ?>"
                                                                data-id="<?php echo e($teacher->id); ?>">Eliminar</button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                No hay registrados de docentes.
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot class="bg-appsalidas">
                                            <tr class="text-center">
                                                <th class="font-weight-bold">Código</th>
                                                <th class="font-weight-bold">Docente</th>
                                                <th class="font-weight-bold">Correo Institucional</th>
                                                <th>...</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <?php echo e($teachers->links()); ?>

                                </div>
                            </div>
                            <div class="card-footer bg-appsalidas py-4"></div>
                        </div>

                    </div>
                    <div class="col-12 col-md-6">
                        <div class="card">
                            <div class="card-header bg-appsalidas py-4">
                                <h4 class="my-0 font-weight-bold">Lista de Estudiantes</h4>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Acá puede visualizar todo los estudiantes que se encuentran
                                    registrados.</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead class="thead-inverse bg-appsalidas">
                                            <tr class="text-center">
                                                <th class="font-weight-bold w-auto">Código</th>
                                                <th class="font-weight-bold w-25">Estudiante</th>
                                                <th class="font-weight-bold w-auto">Correo Institucional</th>
                                                <th class="font-weight-bold w-auto">...</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr class="text-center" id="fila2<?php echo e($loop->iteration); ?>">
                                                    <td><?php echo e($student->code); ?></td>
                                                    <td class="text-capitalize"><?php echo e($student->name); ?> <?php echo e($student->lastname); ?>

                                                    </td>
                                                    <td><?php echo e($student->emailu); ?></td>
                                                    <td>
                                                        <div class="btn-group w-100">
                                                            <a href="<?php echo e(route('user.show-student', $student)); ?>"
                                                                class="btn btn-info  mr-2">Visualizar</a>
                                                            <button class="btn btn-danger delete-student"
                                                                data-tr="<?php echo e($loop->iteration); ?>"
                                                                data-id="<?php echo e($student->id); ?>">Eliminar</button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                No hay registrados de estudiantes.
                                            <?php endif; ?>
                                        </tbody>
                                        <tfoot class="bg-appsalidas">
                                            <tr class="text-center">
                                                <th class="font-weight-bold">Código</th>
                                                <th class="font-weight-bold">Estudiante</th>
                                                <th class="font-weight-bold">Correo Institucional</th>
                                                <th>...</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <?php echo e($students->links()); ?>

                                </div>
                            </div>
                            <div class="card-footer bg-appsalidas py-4"></div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('.delete-student').on('click', function() {
            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡El estudiante será eliminado!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '¡Si, eliminalo!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    var id = $(this).attr('data-id');
                    axios.post("<?php echo e(route('user.delete')); ?>", {
                        _method: 'delete',
                        student_id: id,
                    }).then(response => {
                        Swal.fire(
                            'Eliminado!',
                            response.data,
                            'success'
                        )

                    });
                    var fila = $(this).attr('data-tr');
                    $("#fila2" + fila).remove();
                }
            });
        });

    </script>
    <script>
        $('.delete-teacher').on('click', function() {

            Swal.fire({
                title: '¿Estás seguro?',
                text: "¡El docente será eliminado!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '¡Si, eliminalo!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    var id = $(this).attr('data-id');
                    axios.post("<?php echo e(route('user.delete')); ?>", {
                        _method: 'delete',
                        student_id: id,
                    }).then(response => {
                        Swal.fire(
                            'Eliminado!',
                            response.data,
                            'success'
                        )

                    });
                    var fila = $(this).attr('data-tr');
                    $("#fila1" + fila).remove();
                }
            })
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\AppWebSalidas\resources\views/auth/profiles/program.blade.php ENDPATH**/ ?>