
<?php $__env->startSection('title', 'Listas-Programas'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div>
            <?php if(session()->has('register_complete')): ?>
                <div class="alert alert-success">
                    <strong>¡Éxito!</strong> <?php echo e(session('register_complete')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('register_failed')): ?>
                <div class="alert alert-danger">
                    <strong>¡Error!</strong> <?php echo e(session('register_failed')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-3 mt-2">
                <div class="card">
                    <div class="card-header bg-appsalidas py-4">
                        <h4 class="my-0 font-weight-bold">Registrar Programa</h4>
                    </div>
                    <div class="card-body">
                        <h6 class="card-title text-right font-weight-bold">Por favor llene todas las credenciales</h6>
                        <form action="<?php echo e(route('program.register')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="font-weight-bold">Nombre del programa:</label>
                                <input type="text" name="name" class="form-control"
                                    placeholder="Introduzca el nombre del programa" aria-describedby="helpId"
                                    value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-appsalidas font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Código:</label>
                                <input type="text" name="code" class="form-control"
                                    placeholder="Introduzca el código del programa" aria-describedby="helpId"
                                    value="<?php echo e(old('code')); ?>" maxlength="7"
                                    onKeypress="if (event.keyCode < 45 || event.keyCode > 57) event.returnValue = false;">
                                <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-appsalidas font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Selecciona una facultad:</label>
                                <select name="faculty_id" class="custom-select text-capitalize" aria-describedby="helpId">
                                    <option value="-1">Selecciona una facultad</option>
                                    <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($faculty->id); ?>"><?php echo e($faculty->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['faculty_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small id="helpId" class="text-white bg-appsalidas font-weight-bold"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-block btn-appsalidas">Registrar</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer bg-appsalidas py-4"></div>
                </div>
            </div>
            <div class="col-md-9 mt-2">
                <div class="card">
                    <div class="card-header bg-appsalidas py-4">
                        <h4 class="my-0 font-weight-bold">Lista de Usuarios</h4>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Acá puede visualizar todo las facultades que se encuentran registradas.</h5>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead class="thead-inverse bg-appsalidas">
                                    <tr class="text-center">
                                        <th>No.</th>
                                        <th class="font-weight-bold w-25">Programa</th>
                                        <th class="font-weight-bold w-auto">Estudiantes</th>
                                        <th class="font-weight-bold w-25">Docentes</th>
                                        <th class="font-weight-bold w-25">Actualización</th>
                                        <th class="font-weight-bold w-auto">...</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr class="text-center" id="fila<?php echo e($loop->iteration); ?>">
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td class="text-capitalize"><?php echo e($program->name); ?> </td>
                                            <td><?php echo e($program->students()->count()); ?></td>
                                            <td><?php echo e($program->teachers()->count()); ?></td>
                                            <td>
                                                <div class="btn-group w-100">
                                                    <a href="<?php echo e(route('user.show-program', $program)); ?>"
                                                        class="btn btn-info  mr-2">Visualizar</a>
                                                    <button class="btn btn-danger delete-program"
                                                        data-tr="<?php echo e($loop->iteration); ?>"
                                                        data-id="<?php echo e($program->id); ?>">Eliminar</button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        No hay facultades registradas.
                                    <?php endif; ?>
                                </tbody>
                                <tfoot class="bg-appsalidas">
                                    <tr class="text-center">
                                        <th>No.</th>
                                        <th class="font-weight-bold">Facultad</th>
                                        <th class="font-weight-bold">Programas</th>
                                        <th class="font-weight-bold">Registro</th>
                                        <th class="font-weight-bold">Actualización</th>
                                        <th>...</th>
                                    </tr>
                                </tfoot>
                            </table>
                            <?php echo e($programs->links()); ?>

                        </div>
                    </div>
                    <div class="card-footer bg-appsalidas py-4"></div>
                </div>


            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $('.delete-program').on('click', function() {
        Swal.fire({
            title: '¿Estás seguro?',
            text: "¡El programa será eliminado!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '¡Si, eliminalo!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                var id = $(this).attr('data-id');
                axios.post("<?php echo e(route('program.delete')); ?>", {
                    _method: 'delete',
                    id: id,
                }).then(response => {
                    Swal.fire(
                        'Eliminado!',
                        response.data,
                        'success'
                    );
                    var fila = $(this).attr('data-tr');
                    $("#fila" + fila).remove();
                }).catch(response => {
                    Swal.fire(
                        '¡Error!',
                        'No se ha podido eliminar.',
                        'error'
                    );
                });

            }
        })
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos\Software\AppWebSalidas\resources\views/auth/lists/programs.blade.php ENDPATH**/ ?>